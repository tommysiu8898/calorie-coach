import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useFocusEffect } from "expo-router";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  RefreshControl,
  TouchableOpacity,
  Image,
  Platform,
  Dimensions,
  NativeSyntheticEvent,
  NativeScrollEvent,
  Alert,
  AppState,
  type AppStateStatus,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useRouter } from "expo-router";
import { Swipeable } from "react-native-gesture-handler";
import { useColors } from "@/hooks/useColors";
import { useApp } from "@/context/AppContext";
import { useI18n } from "@/hooks/useI18n";
import Animated, { FadeInDown, useSharedValue, withTiming, useAnimatedProps } from "react-native-reanimated";
import Svg, { Circle } from "react-native-svg";
import { getTodayHealthActivity, refreshHealthConnection, type HealthActivity, isHealthKitAvailable } from "@/lib/health";
import { Ionicons } from "@expo/vector-icons";

const AnimatedCircle = Animated.createAnimatedComponent(Circle);
const { width: SCREEN_WIDTH } = Dimensions.get("window");
const CARD_PADDING = 20;
const CARD_WIDTH = SCREEN_WIDTH - CARD_PADDING * 2;

interface TodayData {
  meals: Meal[];
  totalCalories: number;
  totalProteinG: number;
  totalCarbsG: number;
  totalFatG: number;
  streak: number;
}

interface Meal {
  id: string;
  mealName: string;
  mealType: string;
  totalCalories: number;
  totalProteinG: number;
  totalCarbsG: number;
  totalFatG: number;
  photoUrl?: string;
  createdAt: string;
}

interface Profile {
  dailyCalorieTarget: number;
  dailyProteinTarget: number;
  dailyCarbsTarget: number;
  dailyFatTarget: number;
  goal: string;
}

// Thin arc ring used inside cards
function MiniRing({
  value,
  max,
  color,
  bgColor,
  size = 100,
  strokeWidth = 7,
  children,
}: {
  value: number;
  max: number;
  color: string;
  bgColor: string;
  size?: number;
  strokeWidth?: number;
  children?: React.ReactNode;
}) {
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const progress = useSharedValue(0);

  React.useEffect(() => {
    const pct = max > 0 ? Math.min(value / max, 1) : 0;
    progress.value = withTiming(pct, { duration: 900 });
  }, [value, max]);

  const animatedProps = useAnimatedProps(() => ({
    strokeDashoffset: circumference * (1 - progress.value),
  }));

  return (
    <View style={{ alignItems: "center", justifyContent: "center", width: size, height: size }}>
      <Svg
        width={size}
        height={size}
        style={{ position: "absolute", transform: [{ rotate: "-90deg" }] }}
      >
        <Circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke={bgColor}
          strokeWidth={strokeWidth}
          fill="none"
        />
        <AnimatedCircle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke={color}
          strokeWidth={strokeWidth}
          fill="none"
          strokeDasharray={circumference}
          animatedProps={animatedProps}
          strokeLinecap="round"
        />
      </Svg>
      {children}
    </View>
  );
}

// Week strip calendar — dates are tappable, with prev/next week navigation
// and coloured ring dots showing daily calorie progress.
function WeekStrip({
  colors,
  selectedDate,
  onSelect,
  weekOffset,
  onWeekChange,
  dayData,
  calorieTarget,
}: {
  colors: ReturnType<typeof import("@/hooks/useColors").useColors>;
  selectedDate: Date;
  onSelect: (d: Date) => void;
  weekOffset: number;
  onWeekChange: (offset: number) => void;
  dayData: Record<string, { totalCalories: number; count: number }>;
  calorieTarget: number;
}) {
  const { t } = useI18n();
  const today = new Date();
  const DAY_LABELS = [t("day_sun"), t("day_mon"), t("day_tue"), t("day_wed"), t("day_thu"), t("day_fri"), t("day_sat")];

  const monday = new Date(today);
  monday.setDate(today.getDate() - ((today.getDay() + 6) % 7) + weekOffset * 7);
  monday.setHours(0, 0, 0, 0);
  const days: Date[] = [];
  for (let i = 0; i < 7; i++) {
    const d = new Date(monday);
    d.setDate(monday.getDate() + i);
    days.push(d);
  }

  // Returns a hex colour, "empty" (no meals), or null (future / not loaded)
  const getRingColor = (d: Date): string | "empty" | null => {
    const endOfToday = new Date(today);
    endOfToday.setHours(23, 59, 59, 999);
    if (d > endOfToday) return null;
    const localDate = d.toLocaleDateString("sv");
    const data = dayData[localDate];
    if (!data) return null;
    if (data.count === 0) return "empty";
    if (data.totalCalories <= calorieTarget + 100) return "#00c46a";
    if (data.totalCalories <= calorieTarget + 200) return "#f59e0b";
    return "#ef4444";
  };

  return (
    <View style={{ flexDirection: "row", alignItems: "center", paddingHorizontal: 8 }}>
      <TouchableOpacity
        onPress={() => onWeekChange(weekOffset - 1)}
        style={{ padding: 8 }}
        hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
      >
        <Ionicons name="chevron-back" size={20} color={colors.mutedForeground} />
      </TouchableOpacity>

      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={{ gap: 4, paddingVertical: 4, flexGrow: 1, justifyContent: "space-between" }}
        style={{ flex: 1 }}
      >
        {days.map((d, i) => {
          const isSelected = d.toDateString() === selectedDate.toDateString();
          const isActualToday = d.toDateString() === today.toDateString();
          const ringColor = getRingColor(d);
          // Border config matching the ring-colors.tsx preference screen exactly
          const hasBorder = !isSelected && ringColor !== null;
          const borderColor = ringColor === "empty" ? colors.border : (ringColor ?? "transparent");
          const borderStyle = ringColor === "empty" ? "dashed" : "solid";
          return (
            <TouchableOpacity
              key={i}
              activeOpacity={0.7}
              onPress={() => onSelect(d)}
              style={{ alignItems: "center", paddingHorizontal: 4, paddingVertical: 6 }}
            >
              <Text style={{
                fontSize: 11,
                fontFamily: "Inter_500Medium",
                color: colors.mutedForeground,
                marginBottom: 6,
              }}>
                {DAY_LABELS[d.getDay()]}
              </Text>
              {/* Ring circle — matches the calendar preview in Preferences → Ring Colors */}
              <View
                style={{
                  width: 36,
                  height: 36,
                  borderRadius: 18,
                  borderWidth: hasBorder ? 2 : 0,
                  borderColor: hasBorder ? borderColor : "transparent",
                  borderStyle,
                  backgroundColor: isSelected ? colors.foreground : "transparent",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <Text style={{
                  fontSize: 14,
                  fontFamily: isSelected ? "Inter_700Bold" : "Inter_400Regular",
                  color: isSelected ? colors.primaryForeground : colors.foreground,
                }}>
                  {d.getDate()}
                </Text>
              </View>
              {/* Small dot below to identify today when it is not the selected date */}
              {isActualToday && !isSelected && (
                <View style={{ width: 4, height: 4, borderRadius: 2, backgroundColor: colors.foreground, marginTop: 3 }} />
              )}
            </TouchableOpacity>
          );
        })}
      </ScrollView>

      <TouchableOpacity
        onPress={() => onWeekChange(weekOffset + 1)}
        style={{ padding: 8 }}
        hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
      >
        <Ionicons name="chevron-forward" size={20} color={colors.mutedForeground} />
      </TouchableOpacity>
    </View>
  );
}

// Carousel page 1: Calorie card
function CalorieCard({
  consumed,
  target,
  activeCalories,
  colors,
}: {
  consumed: number;
  target: number;
  activeCalories: number;
  colors: ReturnType<typeof import("@/hooks/useColors").useColors>;
}) {
  const { t } = useI18n();
  const net = Math.max(0, consumed - activeCalories);
  const remaining = Math.max(0, target - net);
  const isOver = net > target;
  const ringColor = isOver ? colors.destructive : colors.calorieColor;
  const showNet = activeCalories > 0;

  return (
    <View
      style={[
        cardStyles.carouselCard,
        { backgroundColor: colors.card, borderColor: colors.border, width: CARD_WIDTH },
      ]}
    >
      {/* Left: big calorie number */}
      <View style={{ flex: 1, justifyContent: "center" }}>
        <Text style={{ fontSize: 13, fontFamily: "Inter_500Medium", color: colors.mutedForeground, marginBottom: 4 }}>
          {t("calories_left")}
        </Text>
        <Text
          style={{
            fontSize: 52,
            fontFamily: "Inter_700Bold",
            color: isOver ? colors.destructive : colors.foreground,
            lineHeight: 58,
          }}
        >
          {remaining}
        </Text>
        {showNet ? (
          <View style={{ marginTop: 4, gap: 2 }}>
            <Text style={{ fontSize: 11, fontFamily: "Inter_400Regular", color: colors.mutedForeground }}>
              {consumed} {t("eaten")} − {activeCalories} {t("activity_active_cal")} = {net} {t("net_calories_label")}
            </Text>
            <Text style={{ fontSize: 11, fontFamily: "Inter_400Regular", color: colors.mutedForeground }}>
              {t("goal")} {target} kcal
            </Text>
          </View>
        ) : (
          <Text style={{ fontSize: 13, fontFamily: "Inter_400Regular", color: colors.mutedForeground, marginTop: 4 }}>
            {consumed} {t("eaten")} · {target} {t("goal")}
          </Text>
        )}
        {isOver && (
          <Text style={{ fontSize: 12, color: colors.destructive, fontFamily: "Inter_500Medium", marginTop: 4 }}>
            {net - target} {t("kcal_over_goal")}
          </Text>
        )}
      </View>
      {/* Right: thin ring */}
      <MiniRing value={showNet ? net : consumed} max={target} color={ringColor} bgColor={colors.calorieRingBg} size={110} strokeWidth={8}>
        <Text style={{ fontSize: 24 }}>🔥</Text>
      </MiniRing>
    </View>
  );
}

// Activity card — shown when HealthKit is available on device
function ActivityCard({
  activity,
  colors,
  onConnectPress,
}: {
  activity: HealthActivity | null;
  colors: ReturnType<typeof import("@/hooks/useColors").useColors>;
  onConnectPress?: () => void;
}) {
  const { t } = useI18n();

  // Only render on iOS devices where HealthKit is available
  if (!isHealthKitAvailable()) return null;
  if (!activity) return null;
  if (!activity.isAvailable) return null;

  // Not yet authorized — show a connect prompt
  if (!activity.isAuthorized) {
    return (
      <View
        style={{
          marginHorizontal: 20,
          marginTop: 14,
          backgroundColor: colors.card,
          borderRadius: 16,
          borderWidth: 1,
          borderColor: colors.border,
          padding: 14,
          flexDirection: "row",
          alignItems: "center",
          gap: 12,
        }}
      >
        <Text style={{ fontSize: 28 }}>❤️</Text>
        <View style={{ flex: 1 }}>
          <Text style={{ fontSize: 13, fontFamily: "Inter_600SemiBold", color: colors.foreground, marginBottom: 2 }}>
            {t("activity_card_title")}
          </Text>
          <Text style={{ fontSize: 12, fontFamily: "Inter_400Regular", color: colors.mutedForeground }}>
            {t("ah_not_connected_notice")}
          </Text>
        </View>
        <TouchableOpacity
          onPress={onConnectPress}
          activeOpacity={0.8}
          style={{
            backgroundColor: "#22c55e",
            borderRadius: 10,
            paddingHorizontal: 12,
            paddingVertical: 7,
          }}
        >
          <Text style={{ fontSize: 12, fontFamily: "Inter_600SemiBold", color: "#fff" }}>
            {t("ah_connect_btn")}
          </Text>
        </TouchableOpacity>
      </View>
    );
  }

  const stats = [
    { emoji: "👣", label: t("activity_steps"), value: activity.steps.toLocaleString(), color: "#3b82f6" },
    { emoji: "🔥", label: t("activity_active_cal"), value: `${activity.activeCalories}`, color: "#f97316" },
    { emoji: "🏋️", label: t("activity_workouts"), value: String(activity.workouts.length), color: "#8b5cf6" },
  ];

  return (
    <View
      style={{
        marginHorizontal: 20,
        marginTop: 14,
        backgroundColor: colors.card,
        borderRadius: 16,
        borderWidth: 1,
        borderColor: colors.border,
        padding: 14,
      }}
    >
      <View style={{ flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 12 }}>
        <Text style={{ fontSize: 16 }}>❤️</Text>
        <Text style={{ fontSize: 13, fontFamily: "Inter_600SemiBold", color: colors.foreground }}>
          {t("activity_card_title")}
        </Text>
      </View>
      <View style={{ flexDirection: "row", gap: 8 }}>
        {stats.map((s) => (
          <View
            key={s.label}
            style={{
              flex: 1,
              backgroundColor: s.color + "14",
              borderRadius: 12,
              padding: 10,
              alignItems: "center",
            }}
          >
            <Text style={{ fontSize: 18, marginBottom: 4 }}>{s.emoji}</Text>
            <Text style={{ fontSize: 16, fontFamily: "Inter_700Bold", color: colors.foreground }}>{s.value}</Text>
            <Text style={{ fontSize: 10, fontFamily: "Inter_500Medium", color: colors.mutedForeground, textAlign: "center", marginTop: 2 }}>
              {s.label}
            </Text>
          </View>
        ))}
      </View>
    </View>
  );
}

// Net Calories card — food intake minus active and resting burned
function NetCaloriesCard({
  consumed,
  activeCalories,
  basalCalories,
  colors,
}: {
  consumed: number;
  activeCalories: number | null;
  basalCalories: number | null;
  colors: ReturnType<typeof import("@/hooks/useColors").useColors>;
}) {
  const { t } = useI18n();
  const isAuthorized = activeCalories !== null && basalCalories !== null;
  const net = isAuthorized ? consumed - activeCalories : null;
  const isDeficit = net !== null && net < -100;
  const isSurplus = net !== null && net > 100;
  const statusColor = isSurplus ? "#f97316" : isDeficit ? "#22c55e" : "#3b82f6";
  const statusLabel = isSurplus ? t("net_surplus") : isDeficit ? t("net_deficit") : t("net_maintenance");
  const statusArrow = isSurplus ? "▲" : isDeficit ? "▼" : "●";

  return (
    <View
      style={{
        marginHorizontal: 20,
        marginTop: 14,
        backgroundColor: colors.card,
        borderRadius: 16,
        borderWidth: 1,
        borderColor: colors.border,
        padding: 16,
      }}
    >
      <View style={{ flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 12 }}>
        <Text style={{ fontSize: 16 }}>🔥</Text>
        <Text style={{ fontSize: 13, fontFamily: "Inter_600SemiBold", color: colors.foreground }}>
          {t("net_calories_title")}
        </Text>
      </View>
      <View style={{ gap: 6 }}>
        <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
          <Text style={{ fontSize: 13, fontFamily: "Inter_400Regular", color: colors.mutedForeground }}>
            {t("net_food_intake")}
          </Text>
          <Text style={{ fontSize: 13, fontFamily: "Inter_600SemiBold", color: colors.foreground }}>
            {consumed.toLocaleString()} kcal
          </Text>
        </View>
        <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
          <Text style={{ fontSize: 13, fontFamily: "Inter_400Regular", color: colors.mutedForeground }}>
            {t("net_active_burned")}
          </Text>
          <Text style={{ fontSize: 13, fontFamily: "Inter_600SemiBold", color: "#f97316" }}>
            {activeCalories !== null ? `−${activeCalories.toLocaleString()} kcal` : "—"}
          </Text>
        </View>
        <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
          <Text style={{ fontSize: 13, fontFamily: "Inter_400Regular", color: colors.mutedForeground }}>
            {t("net_resting_burned")}
          </Text>
          <Text style={{ fontSize: 13, fontFamily: "Inter_600SemiBold", color: "#6366f1" }}>
            {basalCalories !== null ? `−${basalCalories.toLocaleString()} kcal` : "—"}
          </Text>
        </View>
        <View
          style={{
            height: StyleSheet.hairlineWidth,
            backgroundColor: colors.border,
            marginVertical: 6,
          }}
        />
        <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
          <Text style={{ fontSize: 15, fontFamily: "Inter_700Bold", color: colors.foreground }}>
            {t("net_label")}
          </Text>
          <Text style={{ fontSize: 18, fontFamily: "Inter_700Bold", color: net !== null ? statusColor : colors.mutedForeground }}>
            {net !== null ? `${net >= 0 ? "+" : ""}${net.toLocaleString()} kcal` : "—"}
          </Text>
        </View>
      </View>
      {net !== null && (
        <View
          style={{
            marginTop: 12,
            backgroundColor: statusColor + "18",
            borderRadius: 10,
            paddingHorizontal: 12,
            paddingVertical: 7,
            flexDirection: "row",
            alignItems: "center",
            gap: 6,
          }}
        >
          <Text style={{ fontSize: 12, color: statusColor, fontFamily: "Inter_700Bold" }}>
            {statusArrow} {Math.abs(net).toLocaleString()} kcal {statusLabel}
          </Text>
        </View>
      )}
    </View>
  );
}

// Carousel page 2: rotating daily wellness tip
const WELLNESS_TIPS: Record<string, { icon: string; cat: string; text: string }[]> = {
  en: [
    { icon: "💧", cat: "Hydration",   text: "Aim for 8 glasses of water today. Staying hydrated boosts energy and helps control appetite." },
    { icon: "🥦", cat: "Nutrition",   text: "Fill half your plate with vegetables — rich in fibre and nutrients to keep you fuller longer." },
    { icon: "🚶", cat: "Activity",    text: "A 10-minute walk after meals lowers blood sugar and aids digestion." },
    { icon: "😴", cat: "Sleep",       text: "Poor sleep raises hunger hormones. Aim for 7–9 hours to support your goals." },
    { icon: "🥩", cat: "Protein",     text: "Include a protein source in every meal. It reduces cravings and supports muscle." },
    { icon: "🧘", cat: "Mindfulness", text: "Eat slowly and without screens. It takes 20 minutes for your brain to feel full." },
    { icon: "📋", cat: "Planning",    text: "Prep tomorrow's meals tonight. Planning ahead cuts impulsive food choices." },
  ],
  "zh-TW": [
    { icon: "💧", cat: "補水",   text: "今天目標喝8杯水，充足水分能提升能量，有助於控制食慾。" },
    { icon: "🥦", cat: "營養",   text: "讓蔬菜佔餐盤一半，富含纖維和營養素，讓你更長時間保持飽足感。" },
    { icon: "🚶", cat: "運動",   text: "飯後散步10分鐘有助於降低血糖，促進消化。" },
    { icon: "😴", cat: "睡眠",   text: "睡眠不足會提高飢餓素水平。每天保持7–9小時睡眠來支持你的目標。" },
    { icon: "🥩", cat: "蛋白質", text: "每餐都要攝取蛋白質，能減少食慾並幫助維持肌肉。" },
    { icon: "🧘", cat: "正念",   text: "放下手機慢慢吃，大腦需要20分鐘才能感受到飽足感。" },
    { icon: "📋", cat: "計劃",   text: "今晚準備好明天的餐食，提前計劃能減少衝動飲食。" },
  ],
  "zh-CN": [
    { icon: "💧", cat: "补水",   text: "今天目标喝8杯水，充足水分能提升能量，有助于控制食欲。" },
    { icon: "🥦", cat: "营养",   text: "让蔬菜占餐盘一半，富含纤维和营养素，让你更长时间保持饱腹感。" },
    { icon: "🚶", cat: "运动",   text: "饭后散步10分钟有助于降低血糖，促进消化。" },
    { icon: "😴", cat: "睡眠",   text: "睡眠不足会提高饥饿素水平。每天保持7–9小时睡眠来支持你的目标。" },
    { icon: "🥩", cat: "蛋白质", text: "每餐都要摄取蛋白质，能减少食欲并帮助维持肌肉。" },
    { icon: "🧘", cat: "正念",   text: "放下手机慢慢吃，大脑需要20分钟才能感受到饱腹感。" },
    { icon: "📋", cat: "计划",   text: "今晚准备好明天的餐食，提前计划能减少冲动饮食。" },
  ],
};

function WellnessTipsCard({
  colors,
}: {
  colors: ReturnType<typeof import("@/hooks/useColors").useColors>;
}) {
  const { t, languageCode } = useI18n();
  const loc = languageCode === "zh-TW" ? "zh-TW" : languageCode === "zh-CN" ? "zh-CN" : "en";
  const tip = WELLNESS_TIPS[loc][new Date().getDay()];
  return (
    <View style={[cardStyles.carouselCard, { backgroundColor: colors.card, borderColor: colors.border, width: CARD_WIDTH }]}>
      <View style={{ flex: 1, justifyContent: "center" }}>
        <View
          style={{
            alignSelf: "flex-start",
            backgroundColor: colors.primary + "18",
            borderRadius: 8,
            paddingHorizontal: 8,
            paddingVertical: 3,
            marginBottom: 10,
          }}
        >
          <Text style={{ fontSize: 11, fontFamily: "Inter_600SemiBold", color: colors.primary }}>
            {t("wellness_tip_title")} · {tip.cat}
          </Text>
        </View>
        <Text style={{ fontSize: 14, fontFamily: "Inter_400Regular", color: colors.foreground, lineHeight: 22 }}>
          {tip.text}
        </Text>
      </View>
      <Text style={{ fontSize: 44, lineHeight: 52 }}>{tip.icon}</Text>
    </View>
  );
}

// Recently uploaded meal row
function RecentMealRow({
  meal,
  colors,
  onPress,
  onDelete,
}: {
  meal: Meal;
  colors: ReturnType<typeof import("@/hooks/useColors").useColors>;
  onPress?: () => void;
  onDelete?: (id: string) => void;
}) {
  const { t, languageCode } = useI18n();
  const swipeableRef = useRef<Swipeable>(null);
  const [photoError, setPhotoError] = useState(false);
  const intlLocale = languageCode === "zh-TW" ? "zh-TW" : languageCode === "zh-CN" ? "zh-CN" : "en-US";
  const time = new Date(meal.createdAt).toLocaleTimeString(intlLocale, { hour: "numeric", minute: "2-digit" });
  const photoUri =
    !photoError && meal.photoUrl
      ? meal.photoUrl.startsWith("/api")
        ? `https://${process.env.EXPO_PUBLIC_DOMAIN}${meal.photoUrl}`
        : meal.photoUrl
      : null;

  const renderRightActions = () => (
    <TouchableOpacity
      style={recentRowStyles.deleteAction}
      onPress={() => {
        swipeableRef.current?.close();
        Alert.alert(
          t("delete_meal"),
          t("delete_meal_confirm"),
          [
            { text: t("cancel"), style: "cancel" },
            {
              text: t("delete"),
              style: "destructive",
              onPress: () => onDelete?.(meal.id),
            },
          ],
        );
      }}
    >
      <Text style={recentRowStyles.deleteText}>{t("delete")}</Text>
    </TouchableOpacity>
  );

  return (
    <Swipeable ref={swipeableRef} renderRightActions={renderRightActions} rightThreshold={40} overshootRight={false}>
      <TouchableOpacity
        activeOpacity={0.78}
        onPress={onPress}
        style={[
          cardStyles.recentRow,
          { backgroundColor: colors.card, borderColor: colors.border },
        ]}
      >
        {photoUri ? (
          <Image source={{ uri: photoUri }} style={cardStyles.recentPhoto} resizeMode="cover" onError={() => setPhotoError(true)} />
        ) : (
          <View style={[cardStyles.recentPhoto, { backgroundColor: colors.muted, alignItems: "center", justifyContent: "center" }]}>
            <Text style={{ fontSize: 24 }}>🍽</Text>
          </View>
        )}
        <View style={{ flex: 1 }}>
          <Text style={{ fontSize: 14, fontFamily: "Inter_600SemiBold", color: colors.foreground }} numberOfLines={1}>
            {meal.mealName}
          </Text>
          <Text style={{ fontSize: 12, fontFamily: "Inter_400Regular", color: colors.mutedForeground, marginTop: 2 }}>
            {t(meal.mealType) !== meal.mealType ? t(meal.mealType) : capitalize(meal.mealType)} · {time}
          </Text>
          <View style={{ flexDirection: "row", gap: 6, marginTop: 5 }}>
            <View style={{ backgroundColor: colors.proteinColor + "22", borderRadius: 6, paddingHorizontal: 6, paddingVertical: 2 }}>
              <Text style={{ fontSize: 10, fontFamily: "Inter_600SemiBold", color: colors.proteinColor }}>
                {t("protein_abbr")} {Math.round(meal.totalProteinG)}g
              </Text>
            </View>
            <View style={{ backgroundColor: colors.carbsColor + "22", borderRadius: 6, paddingHorizontal: 6, paddingVertical: 2 }}>
              <Text style={{ fontSize: 10, fontFamily: "Inter_600SemiBold", color: colors.carbsColor }}>
                {t("carbs_abbr")} {Math.round(meal.totalCarbsG)}g
              </Text>
            </View>
            <View style={{ backgroundColor: colors.fatColor + "22", borderRadius: 6, paddingHorizontal: 6, paddingVertical: 2 }}>
              <Text style={{ fontSize: 10, fontFamily: "Inter_600SemiBold", color: colors.fatColor }}>
                {t("fat_abbr")} {Math.round(meal.totalFatG)}g
              </Text>
            </View>
          </View>
        </View>
        <Text style={{ fontSize: 15, fontFamily: "Inter_700Bold", color: colors.foreground }}>
          {meal.totalCalories}
        </Text>
        <Text style={{ fontSize: 12, fontFamily: "Inter_400Regular", color: colors.mutedForeground }}>
          {" "}{t("kcal_abbr")}
        </Text>
      </TouchableOpacity>
    </Swipeable>
  );
}

const recentRowStyles = StyleSheet.create({
  deleteAction: {
    backgroundColor: "#ef4444",
    justifyContent: "center",
    alignItems: "center",
    width: 80,
    borderRadius: 14,
    marginBottom: 10,
  },
  deleteText: {
    color: "#fff",
    fontSize: 14,
    fontFamily: "Inter_600SemiBold",
  },
});

function capitalize(s: string) {
  return s.charAt(0).toUpperCase() + s.slice(1);
}

// Nutrition score bar — between carousel and meal list
function HealthScoreBar({
  consumed, target,
  protein, proteinTarget,
  carbs, carbsTarget,
  fat, fatTarget,
  colors,
}: {
  consumed: number; target: number;
  protein: number; proteinTarget: number;
  carbs: number; carbsTarget: number;
  fat: number; fatTarget: number;
  colors: ReturnType<typeof import("@/hooks/useColors").useColors>;
}) {
  const { t } = useI18n();
  const calPct   = target         > 0 ? Math.min(consumed / target, 1)         : 0;
  const protPct  = proteinTarget  > 0 ? Math.min(protein / proteinTarget, 1)   : 0;
  const carbPct  = carbsTarget    > 0 ? Math.min(carbs / carbsTarget, 1)       : 0;
  const fatPct   = fatTarget      > 0 ? Math.min(fat / fatTarget, 1)           : 0;

  // Penalise going over calories
  const calScore = consumed > target && target > 0
    ? Math.max(0, 1 - (consumed - target) / target)
    : calPct;
  const avgScore = (calScore + protPct + carbPct + fatPct) / 4;

  let scoreLabel = t("score_poor");
  let scoreColor = "#ef4444";
  if (avgScore >= 0.8)      { scoreLabel = t("score_excellent"); scoreColor = "#22c55e"; }
  else if (avgScore >= 0.6) { scoreLabel = t("score_good");      scoreColor = "#84cc16"; }
  else if (avgScore >= 0.35){ scoreLabel = t("score_fair");      scoreColor = "#f59e0b"; }

  const bars = [
    { label: t("cal_abbr"),     pct: calPct,  color: colors.calorieColor  },
    { label: t("protein_abbr"), pct: protPct, color: colors.proteinColor  },
    { label: t("carbs_abbr"),   pct: carbPct, color: colors.carbsColor    },
    { label: t("fat_abbr"),     pct: fatPct,  color: colors.fatColor      },
  ];

  return (
    <View style={{ paddingHorizontal: 20, marginTop: 18 }}>
      <View
        style={{
          backgroundColor: colors.card,
          borderRadius: 16,
          borderWidth: 1,
          borderColor: colors.border,
          padding: 14,
        }}
      >
        <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
          <Text style={{ fontSize: 13, fontFamily: "Inter_600SemiBold", color: colors.mutedForeground }}>
            {t("health_score")}
          </Text>
          <View style={{ backgroundColor: scoreColor + "26", borderRadius: 20, paddingHorizontal: 10, paddingVertical: 3 }}>
            <Text style={{ fontSize: 12, fontFamily: "Inter_700Bold", color: scoreColor }}>
              {scoreLabel}
            </Text>
          </View>
        </View>
        <View style={{ flexDirection: "row", gap: 10 }}>
          {bars.map(({ label, pct, color }) => (
            <View key={label} style={{ flex: 1, alignItems: "center" }}>
              <View
                style={{
                  width: "100%",
                  height: 6,
                  backgroundColor: colors.muted,
                  borderRadius: 3,
                  overflow: "hidden",
                }}
              >
                <View
                  style={{
                    width: `${Math.min(Math.round(pct * 100), 100)}%`,
                    height: "100%",
                    backgroundColor: color,
                    borderRadius: 3,
                  }}
                />
              </View>
              <Text
                style={{
                  fontSize: 10,
                  fontFamily: "Inter_500Medium",
                  color: colors.mutedForeground,
                  marginTop: 4,
                }}
              >
                {label} {Math.round(pct * 100)}%
              </Text>
            </View>
          ))}
        </View>
      </View>
    </View>
  );
}

const cardStyles = StyleSheet.create({
  carouselCard: {
    flexDirection: "row",
    alignItems: "center",
    borderRadius: 20,
    borderWidth: 1,
    padding: 20,
    gap: 16,
  },
  miniMacroCard: {
    borderRadius: 16,
    borderWidth: 1,
    padding: 14,
    alignItems: "center",
  },
  recentRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    borderRadius: 14,
    borderWidth: 1,
    padding: 12,
    marginBottom: 10,
  },
  recentPhoto: {
    width: 82,
    height: 82,
    borderRadius: 12,
    flexShrink: 0,
  },
});

export default function HomeScreen() {
  const colors = useColors();
  const { t, languageCode } = useI18n();
  const insets = useSafeAreaInsets();
  const { userId, addBurnedCalories } = useApp();
  const router = useRouter();
  const queryClient = useQueryClient();
  const [refreshing, setRefreshing] = useState(false);
  const [carouselPage, setCarouselPage] = useState(0);
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [weekOffset, setWeekOffset] = useState(0);
  const scrollRef = useRef<ScrollView>(null);
  const [healthActivity, setHealthActivity] = useState<HealthActivity | null>(null);

  const selectedLocalDate = selectedDate.toLocaleDateString("sv");
  const isViewingToday = selectedDate.toDateString() === new Date().toDateString();

  // Week navigation helper — also moves the selected date into the new week
  const handleWeekChange = useCallback((newOffset: number) => {
    setWeekOffset(newOffset);
    const now = new Date();
    if (newOffset === 0) {
      setSelectedDate(now);
    } else {
      const mon = new Date(now);
      mon.setDate(now.getDate() - ((now.getDay() + 6) % 7) + newOffset * 7);
      setSelectedDate(mon);
    }
  }, []);

  // Monday of the currently displayed week (stable key for the query)
  const weekMondayStr = useMemo(() => {
    const now = new Date();
    const mon = new Date(now);
    mon.setDate(now.getDate() - ((now.getDay() + 6) % 7) + weekOffset * 7);
    mon.setHours(0, 0, 0, 0);
    return mon.toLocaleDateString("sv");
  }, [weekOffset]);
  const intlLocale = languageCode === "zh-TW" ? "zh-TW" : languageCode === "zh-CN" ? "zh-CN" : "en-US";

  const {
    data: today,
    refetch: refetchToday,
    isLoading: todayLoading,
  } = useQuery<TodayData>({
    queryKey: ["today", userId, selectedLocalDate],
    queryFn: async () => {
      const res = await fetch(
        `https://${process.env.EXPO_PUBLIC_DOMAIN}/api/meals/today?userId=${userId}&localDate=${selectedLocalDate}`,
      );
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
    enabled: !!userId,
    refetchInterval: isViewingToday ? 15000 : false,
  });

  const { data: profile } = useQuery<Profile>({
    queryKey: ["profile", userId],
    queryFn: async () => {
      const res = await fetch(
        `https://${process.env.EXPO_PUBLIC_DOMAIN}/api/profile?userId=${userId}`,
      );
      if (!res.ok) throw new Error("No profile");
      return res.json();
    },
    enabled: !!userId,
  });

  const { data: userStats } = useQuery<{ streakDays: number; vitalityScore: number } | null>({
    queryKey: ["userStats", userId],
    queryFn: async () => {
      const res = await fetch(
        `https://${process.env.EXPO_PUBLIC_DOMAIN}/api/user-stats?userId=${userId}`,
      );
      if (!res.ok) return null;
      const data = await res.json() as { exists: boolean; stats: { streakDays: number; vitalityScore: number } | null };
      return data.stats ?? null;
    },
    enabled: !!userId,
    staleTime: 60000,
  });

  // Fetch daily calorie totals for every day in the currently displayed week
  const { data: weekSummary = {} } = useQuery<Record<string, { totalCalories: number; count: number }>>({
    queryKey: ["weekSummary", userId, weekMondayStr],
    queryFn: async () => {
      const monday = new Date(weekMondayStr);
      const days = Array.from({ length: 7 }, (_, i) => {
        const d = new Date(monday);
        d.setDate(monday.getDate() + i);
        return d;
      });
      const results: Record<string, { totalCalories: number; count: number }> = {};
      await Promise.all(
        days.map(async (d) => {
          const localDate = d.toLocaleDateString("sv");
          try {
            const res = await fetch(
              `https://${process.env.EXPO_PUBLIC_DOMAIN}/api/meals/today?userId=${userId}&localDate=${localDate}`,
            );
            if (res.ok) {
              const data = await res.json() as { totalCalories: number; meals: unknown[] };
              results[localDate] = { totalCalories: data.totalCalories ?? 0, count: data.meals?.length ?? 0 };
            }
          } catch { /* ignore individual day failures */ }
        }),
      );
      return results;
    },
    enabled: !!userId,
    staleTime: 120_000,
  });

  const loadHealthData = useCallback(async () => {
    try {
      // Re-probe live HealthKit authorization so revoked permissions are
      // caught immediately without waiting for Profile tab focus.
      await refreshHealthConnection();
      const data = await getTodayHealthActivity();
      setHealthActivity(data);
    } catch {
      // graceful fallback
    }
  }, []);

  useEffect(() => {
    loadHealthData();
    const sub = AppState.addEventListener("change", (state: AppStateStatus) => {
      if (state === "active") {
        loadHealthData();
      }
    });
    return () => sub.remove();
  }, [loadHealthData]);

  // Refresh health data on route focus so data updates immediately after
  // returning from the /apple-health connection screen.
  useFocusEffect(
    useCallback(() => {
      loadHealthData();
    }, [loadHealthData]),
  );

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await Promise.all([refetchToday(), loadHealthData()]);
    setRefreshing(false);
  }, [refetchToday, loadHealthData]);

  const handleDeleteMeal = async (mealId: string) => {
    try {
      const res = await fetch(
        `https://${process.env.EXPO_PUBLIC_DOMAIN}/api/meals/${mealId}?userId=${userId}`,
        { method: "DELETE" },
      );
      if (!res.ok) throw new Error("Failed to delete meal");
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: ["today", userId] }),
        queryClient.invalidateQueries({ queryKey: ["mealHistory", userId] }),
        queryClient.invalidateQueries({ queryKey: ["dailyLogs", userId] }),
      ]);
    } catch {
      Alert.alert(t("delete_meal"), t("delete_error"));
    }
  };

  const consumed = today?.totalCalories ?? 0;
  const target = profile?.dailyCalorieTarget ?? 2000;
  const activeCaloriesFromHealth = (addBurnedCalories && healthActivity?.isAuthorized ? healthActivity.activeCalories : 0) ?? 0;
  const protein = today?.totalProteinG ?? 0;
  const carbs = today?.totalCarbsG ?? 0;
  const fat = today?.totalFatG ?? 0;
  const proteinTarget = profile?.dailyProteinTarget ?? 150;
  const carbsTarget = profile?.dailyCarbsTarget ?? 250;
  const fatTarget = profile?.dailyFatTarget ?? 65;
  const streak = userStats?.streakDays ?? today?.streak ?? 0;

  const handleCarouselScroll = (e: NativeSyntheticEvent<NativeScrollEvent>) => {
    const pageIndex = Math.round(e.nativeEvent.contentOffset.x / SCREEN_WIDTH);
    setCarouselPage(pageIndex);
  };

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: colors.background }}
      contentContainerStyle={{
        paddingTop: insets.top + (Platform.OS === "web" ? 67 : 0),
        paddingBottom: insets.bottom + 90,
      }}
      showsVerticalScrollIndicator={false}
      refreshControl={
        <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.foreground} />
      }
    >
      {/* Header */}
      <Animated.View
        entering={FadeInDown.delay(0)}
        style={{
          flexDirection: "row",
          justifyContent: "space-between",
          alignItems: "center",
          paddingHorizontal: 20,
          paddingVertical: 12,
        }}
      >
        <Text style={{ fontSize: 24, fontFamily: "Inter_700Bold", color: colors.foreground }}>
          Calories Coach
        </Text>
      </Animated.View>

      {/* Streak badge row */}
      {streak > 0 && (
        <Animated.View
          entering={FadeInDown.delay(30)}
          style={{ paddingHorizontal: 20, marginBottom: 4, marginTop: -4 }}
        >
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              gap: 6,
              alignSelf: "flex-start",
              backgroundColor: "#ff6b0022",
              paddingHorizontal: 12,
              paddingVertical: 5,
              borderRadius: 20,
              borderWidth: 1,
              borderColor: "#ff6b0033",
            }}
          >
            <Text style={{ fontSize: 15 }}>🔥</Text>
            <Text style={{ fontSize: 13, fontFamily: "Inter_700Bold", color: "#cc4400" }}>
              {streak} {t("streak_badge_label")}
            </Text>
          </View>
        </Animated.View>
      )}

      {/* Week strip */}
      <Animated.View entering={FadeInDown.delay(60)}>
        <WeekStrip
          colors={colors}
          selectedDate={selectedDate}
          onSelect={setSelectedDate}
          weekOffset={weekOffset}
          onWeekChange={handleWeekChange}
          dayData={weekSummary}
          calorieTarget={target}
        />
      </Animated.View>

      {/* Carousel */}
      <Animated.View entering={FadeInDown.delay(120)} style={{ marginTop: 16 }}>
        <ScrollView
          ref={scrollRef}
          horizontal
          showsHorizontalScrollIndicator={false}
          decelerationRate="fast"
          snapToInterval={SCREEN_WIDTH}
          snapToAlignment="start"
          onMomentumScrollEnd={handleCarouselScroll}
          scrollEventThrottle={16}
        >
          <View style={{ width: SCREEN_WIDTH, paddingHorizontal: CARD_PADDING }}>
            <CalorieCard consumed={consumed} target={target} activeCalories={activeCaloriesFromHealth} colors={colors} />
          </View>
          <View style={{ width: SCREEN_WIDTH, paddingHorizontal: CARD_PADDING }}>
            <WellnessTipsCard colors={colors} />
          </View>
        </ScrollView>
        {/* Pagination dots */}
        <View style={{ flexDirection: "row", justifyContent: "center", gap: 6, marginTop: 12 }}>
          {[0, 1].map((i) => (
            <View
              key={i}
              style={{
                width: i === carouselPage ? 16 : 6,
                height: 6,
                borderRadius: 3,
                backgroundColor: i === carouselPage ? colors.foreground : colors.border,
              }}
            />
          ))}
        </View>
      </Animated.View>

      {/* Compact macro trio — protein / carbs / fat side by side */}
      <Animated.View entering={FadeInDown.delay(155)} style={{ paddingHorizontal: 20, marginTop: 16 }}>
        <View style={{ flexDirection: "row", gap: 10 }}>
          {[
            { emoji: "🥩", labelKey: "protein", value: protein, target: proteinTarget, color: colors.proteinColor },
            { emoji: "🌾", labelKey: "carbs",   value: carbs,   target: carbsTarget,   color: colors.carbsColor   },
            { emoji: "🫐", labelKey: "fat",     value: fat,     target: fatTarget,     color: colors.fatColor     },
          ].map(({ emoji, labelKey, value, target: tgt, color }) => {
            const pct = tgt > 0 ? Math.min(value / tgt, 1) : 0;
            const left = Math.max(0, Math.round(tgt - value));
            return (
              <View
                key={labelKey}
                style={{
                  flex: 1,
                  backgroundColor: colors.card,
                  borderRadius: 16,
                  borderWidth: 1,
                  borderColor: colors.border,
                  padding: 12,
                  alignItems: "center",
                }}
              >
                <Text style={{ fontSize: 22, marginBottom: 4 }}>{emoji}</Text>
                <Text style={{ fontSize: 20, fontFamily: "Inter_700Bold", color: colors.foreground, lineHeight: 24 }}>
                  {left}g
                </Text>
                <Text style={{ fontSize: 10, fontFamily: "Inter_400Regular", color: colors.mutedForeground, marginTop: 2, textAlign: "center" }}>
                  {t(labelKey)} {t("left")}
                </Text>
                <View
                  style={{
                    width: "100%",
                    height: 5,
                    backgroundColor: colors.muted,
                    borderRadius: 3,
                    marginTop: 8,
                    overflow: "hidden",
                  }}
                >
                  <View
                    style={{
                      width: `${Math.min(Math.round(pct * 100), 100)}%`,
                      height: "100%",
                      backgroundColor: color,
                      borderRadius: 3,
                    }}
                  />
                </View>
                <Text style={{ fontSize: 9, fontFamily: "Inter_500Medium", color: colors.mutedForeground, marginTop: 4 }}>
                  {Math.round(value)}g / {Math.round(tgt)}g
                </Text>
              </View>
            );
          })}
        </View>
      </Animated.View>

      {/* Nutrition score bar */}
      <Animated.View entering={FadeInDown.delay(170)}>
        <HealthScoreBar
          consumed={consumed} target={target}
          protein={protein} proteinTarget={proteinTarget}
          carbs={carbs} carbsTarget={carbsTarget}
          fat={fat} fatTarget={fatTarget}
          colors={colors}
        />
      </Animated.View>

      {/* Net Calories card — always visible when viewing today; shows "—" for burned when health not connected */}
      {isViewingToday && (
        <Animated.View entering={FadeInDown.delay(185)}>
          <NetCaloriesCard
            consumed={consumed}
            activeCalories={healthActivity?.isAuthorized ? healthActivity.activeCalories : null}
            basalCalories={healthActivity?.isAuthorized ? healthActivity.basalCalories : null}
            colors={colors}
          />
        </Animated.View>
      )}

      {/* Activity card from Apple Health */}
      {isViewingToday && (
        <Animated.View entering={FadeInDown.delay(195)}>
          <ActivityCard
            activity={healthActivity}
            colors={colors}
            onConnectPress={() => router.push("/apple-health")}
          />
        </Animated.View>
      )}

      {/* Meal list for selected date */}
      <Animated.View entering={FadeInDown.delay(200)} style={{ paddingHorizontal: 20, marginTop: 22 }}>
        <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
          <Text style={{ fontSize: 17, fontFamily: "Inter_700Bold", color: colors.foreground }}>
            {isViewingToday
              ? t("today_meals")
              : `${t("meals_on")} ${selectedDate.toLocaleDateString(intlLocale, { month: "short", day: "numeric" })}`}
          </Text>
          {(today?.meals?.length ?? 0) > 0 && (
            <TouchableOpacity onPress={() => router.push("/(tabs)/history")}>
              <Text style={{ fontSize: 14, fontFamily: "Inter_500Medium", color: colors.mutedForeground }}>
                {t("see_all")}
              </Text>
            </TouchableOpacity>
          )}
        </View>

        {todayLoading ? (
          <View style={{ paddingVertical: 32, alignItems: "center" }}>
            <Text style={{ color: colors.mutedForeground, fontFamily: "Inter_400Regular" }}>{t("loading")}</Text>
          </View>
        ) : today?.meals && today.meals.length > 0 ? (
          today.meals.slice().reverse().map((meal, i) => (
            <Animated.View key={meal.id} entering={FadeInDown.delay(240 + i * 50)}>
              <RecentMealRow meal={meal} colors={colors} onPress={() => router.push(`/meal-detail?id=${meal.id}`)} onDelete={handleDeleteMeal} />
            </Animated.View>
          ))
        ) : (
          <View
            style={{
              alignItems: "center",
              padding: 36,
              borderRadius: 20,
              borderWidth: 1.5,
              borderStyle: "dashed",
              borderColor: colors.border,
            }}
          >
            <Text style={{ fontSize: 15, fontFamily: "Inter_600SemiBold", color: colors.foreground, marginBottom: 4 }}>
              {t("no_meals")}
            </Text>
            <Text style={{ fontSize: 13, fontFamily: "Inter_400Regular", color: colors.mutedForeground, textAlign: "center" }}>
              {t("no_meals_sub")}
            </Text>
          </View>
        )}
      </Animated.View>
    </ScrollView>
  );
}
