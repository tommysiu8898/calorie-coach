// POST /api/search-nearby
// Requires: MAPBOX_ACCESS_TOKEN secret (Replit Secrets)
// Uses Mapbox Geocoding API v6 — current (non-deprecated) endpoint.
// Works with any standard public token (pk.*). Free tier: 100,000 requests/month.

import { Router } from "express";

const router = Router();

const PLACES_TIMEOUT_MS = 8_000;

// Category → Mapbox Geocoding search keyword
const CATEGORY_MAP: Record<string, string> = {
  "健身房": "gym",
  "健身中心": "gym",
  "gym": "gym",
  "fitness": "gym",
  "瑜伽館": "yoga studio",
  "瑜伽馆": "yoga studio",
  "瑜伽": "yoga studio",
  "yoga": "yoga studio",
  "游泳池": "swimming pool",
  "swimming": "swimming pool",
  "pool": "swimming pool",
  "公園": "park",
  "公园": "park",
  "park": "park",
  "nature": "park",
  "自然": "park",
  "outdoor": "park",
  "餐廳": "restaurant",
  "餐厅": "restaurant",
  "餐館": "restaurant",
  "餐馆": "restaurant",
  "restaurant": "restaurant",
  "食肆": "restaurant",
};

function toCategoryKeyword(query: string): string {
  const trimmed = query.trim();
  const lower = trimmed.toLowerCase();
  for (const [key, keyword] of Object.entries(CATEGORY_MAP)) {
    if (lower.includes(key.toLowerCase())) return keyword;
  }
  return "gym";
}

// Mapbox language codes
function appLanguageToMapbox(appLanguage: string): string {
  if (appLanguage === "zh-TW" || appLanguage === "zh-CN") return "zh";
  return "en";
}

// Haversine straight-line distance in km
function haversineKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371;
  const dLat = (lat2 - lat1) * (Math.PI / 180);
  const dLon = (lon2 - lon1) * (Math.PI / 180);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * (Math.PI / 180)) *
      Math.cos(lat2 * (Math.PI / 180)) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  return parseFloat((R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))).toFixed(1));
}

router.post("/search-nearby", async (req, res) => {
  const { query = "gym", lat, lng, appLanguage = "en" } = req.body as {
    query?: string;
    lat?: number;
    lng?: number;
    appLanguage?: string;
  };

  if (typeof lat !== "number" || typeof lng !== "number") {
    return res.status(400).json({ success: false, error: "lat and lng are required numbers" });
  }

  const token = process.env.MAPBOX_ACCESS_TOKEN;
  if (!token) {
    console.warn("[search-nearby] MAPBOX_ACCESS_TOKEN not set — returning empty results");
    return res.json({
      success: true,
      places: [],
      warning: "Location search is not configured on this server.",
    });
  }

  const keyword = toCategoryKeyword(query);
  const language = appLanguageToMapbox(appLanguage);

  console.log(`[search-nearby] lat=${lat} lng=${lng} keyword="${keyword}" lang=${language}`);

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), PLACES_TIMEOUT_MS);

  try {
    // Mapbox Search Box v1 — forward text search (correct API for POI/business lookup).
    // /geocode/v6 is address-only and does not support types=poi.
    // https://docs.mapbox.com/api/search/search-box/
    // Compute a ~25 km bounding box around the user to prevent globally-named
    // places (e.g. "Gym Rd, Canada") from ranking above local results.
    const LAT_DELTA = 0.225; // ≈ 25 km
    const LNG_DELTA = LAT_DELTA / Math.cos((lat * Math.PI) / 180);
    const bbox = `${lng - LNG_DELTA},${lat - LAT_DELTA},${lng + LNG_DELTA},${lat + LAT_DELTA}`;

    const url = new URL("https://api.mapbox.com/search/searchbox/v1/forward");
    url.searchParams.set("q", keyword);
    url.searchParams.set("proximity", `${lng},${lat}`);
    url.searchParams.set("bbox", bbox);
    url.searchParams.set("limit", "10");
    url.searchParams.set("language", language);
    url.searchParams.set("access_token", token);

    const resp = await fetch(url.toString(), { signal: controller.signal });

    if (!resp.ok) {
      const body = await resp.text().catch(() => "");
      throw new Error(`Mapbox API error ${resp.status}: ${body.slice(0, 300)}`);
    }

    const data = (await resp.json()) as {
      features?: Array<{
        geometry?: { coordinates?: [number, number] };
        properties?: {
          name?: string;
          full_address?: string;
          place_formatted?: string;
        };
      }>;
    };

    console.log(`[search-nearby] searchbox/v1 features length: ${data.features?.length ?? 0}`);

    const places = (data.features ?? []).map((f) => {
      const pLng = f.geometry?.coordinates?.[0] ?? lng;
      const pLat = f.geometry?.coordinates?.[1] ?? lat;
      const props = f.properties ?? {};
      return {
        name: props.name ?? "",
        address: props.full_address ?? props.place_formatted ?? "",
        rating: null as number | null,
        distance: haversineKm(lat, lng, pLat, pLng),
        mapsUrl: `https://maps.google.com/?q=${pLat},${pLng}`,
      };
    });

    return res.json({ success: true, places });
  } catch (err) {
    if (err instanceof Error && err.name === "AbortError") {
      return res.status(504).json({
        success: false,
        error: "Location search timed out. Please try again.",
      });
    }
    console.error("[search-nearby] error:", err);
    const detail = err instanceof Error ? err.message.slice(0, 300) : "";
    return res.status(500).json({
      success: false,
      error: detail || "Could not search nearby places. Please try again.",
    });
  } finally {
    clearTimeout(timer);
  }
});

export default router;
